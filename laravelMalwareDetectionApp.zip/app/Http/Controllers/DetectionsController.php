<?php

namespace App\Http\Controllers;

use Exception;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DetectionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (session()->exists("users")) {
            $users = session()->pull("users");
            session()->put("users", $users);

            if ($users['userType'] != 2) {
                return redirect("/");
            }

            $userID = $users['userID'];

            $fromLoading = $request->query('fromLoading');
            $query = DB::table('detections')->where('userID', '=', $userID)->get();
            $data = json_decode($query, true);
            if ($fromLoading) {

                if (count($data) <= 0) {
                    session()->put('noDetections', true);
                }
            }



            return view('user.detections', ['detections' => count($data) > 0 ? $data : [], 'userid' => $userID]);
        }
        return redirect("/");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function disconnectFromNetwork()
    {

        if (session()->exists("users")) {
            $users = session()->pull("users");
            session()->put("users", $users);

            if ($users['userType'] != 2) {
                return redirect("/");
            }

            try {
                shell_exec('powershell -Command "Disable-NetAdapter -Name \"Ethernet\" -Confirm:$false"');
                shell_exec('powershell -Command "Disable-NetAdapter -Name \"Wi-Fi\" -Confirm:$false"');
            } catch (Exception $e) {
            }
            try {
                shell_exec('powershell -Command "Disable-NetAdapter -Name \"Wi-Fi\" -Confirm:$false"');
            } catch (Exception $e) {
                error_log($e);
            }

            return redirect("/detections");
        }
        return redirect("/");
    }
}
